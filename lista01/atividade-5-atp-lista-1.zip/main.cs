using System;

class Program
{
    public static void Main(string[] args)
    {

        double aplicacaoM, taxa, Nmeses, rendimento;

        Console.WriteLine("Digite a Aplicação Mensal");
        aplicacaoM = double.Parse(Console.ReadLine());
        Console.WriteLine("Digite a taxa");
        taxa = double.Parse(Console.ReadLine());
        Console.WriteLine("Digite os meses");
        Nmeses = double.Parse(Console.ReadLine());

        rendimento = aplicacaoM * (Math.Pow(1 + taxa, Nmeses) - 1) / taxa;

        Console.WriteLine("Rendimento: " + rendimento);
    }
}