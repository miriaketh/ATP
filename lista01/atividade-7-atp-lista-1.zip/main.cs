using System;

class Program {
  public static void Main (string[] args) {

    int diasSemAcidentes, anos, meses, dias, resto;
    
    Console.WriteLine ("digite a quantidade de dias sem acidentes:");

    diasSemAcidentes= int.Parse(Console.ReadLine());
    

      anos = diasSemAcidentes / 365;
    resto= diasSemAcidentes % 365;
     meses = resto / 30;
    resto = resto % 30; 
     dias = resto;

    Console.WriteLine ("dias sem acidentes:" + diasSemAcidentes);
     Console.WriteLine ("anos:" + anos);
    Console.WriteLine ("meses:" + meses);
    Console.WriteLine("dias:" + dias );
       
  }
}