using System;

class Program {
  public static void Main (string[] args) {

    Double areaRet, baseRet, perimetro, diagonal, area;

   Console.WriteLine ("Digite a base e a altura:");
    
    baseRet= double.Parse(Console.ReadLine());
    areaRet= double.Parse(Console.ReadLine());

    diagonal= (areaRet * baseRet );
    area= 2* ( areaRet + baseRet);

    perimetro= Math.Sqrt (Math.Pow(areaRet, 2) + Math.Pow(baseRet,2));

    Console.Write(" area: "  + diagonal + "/n");
    Console.Write("Perimetro: " + area + "/n");
    Console.Write( "Diagonal: " + perimetro + "/n");
}
  }