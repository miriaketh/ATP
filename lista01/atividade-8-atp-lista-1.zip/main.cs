using System;

class Program {
  public static void Main (string[] args) {

    Console.WriteLine ("Digite a Conta: ");
    int conta = int.Parse(Console.ReadLine());

    if (conta<1000 && conta > 99) {


    int C = (conta / 100);
    int D = (conta % 100) / 10;
    int U = (conta % 10);


    int inverso = (U*100)+(D*10)+C;
    int Result1 = ((U*100)+(C*100))+((D*10)+(D*10))*2+(C+U)*3;

    int resultado1 = conta + inverso;
    int verificador = Result1 % 10;



      Console.WriteLine("O numero verificador é: " + Result1);
      Console.WriteLine("O Dígito verificador é: " + verificador);
  }
    else {
      Console.WriteLine("Conta inválida");
    }  
  }
}