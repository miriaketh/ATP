using System;

class Program {
  public static void Main (string[] args) {

    double salarioMin, Kilowatt, valor, desconto, valorUni;
    
    Console.WriteLine ("Digite seu salário mínimo e kilowatt");
    salarioMin= Double.Parse(Console.ReadLine());
    Kilowatt= Double.Parse(Console.ReadLine());
    valor= (salarioMin/7) * (Kilowatt/100);
    valorUni= valor/Kilowatt;
    desconto= valor * 0.9;
    }
}