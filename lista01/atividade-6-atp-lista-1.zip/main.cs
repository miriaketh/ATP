using System;

class Program
{
    public static void Main(string[] args)
    {

        double variA, variB, auxilio;

        Console.WriteLine("Digite um número:");
      variA= double.Parse(Console.ReadLine());
      
        Console.WriteLine("Digite o segundo número:");
      variB=double.Parse(Console.ReadLine());

     auxilio = variA;
      variA = variB;
      variB = auxilio;

      Console.WriteLine("O valor de A é: " + variA);
      Console.WriteLine("O valor de B é:" + variB);


    
    }
  }