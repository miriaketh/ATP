using System;

class Program {
  public static void Main (string[] args) {
     double cateto1, cateto2, hipotenusa;
  
    Console.WriteLine ("Digite os catetos:");
    
    cateto2= double.Parse(Console.ReadLine());
    hipotenusa= double.Parse(Console.ReadLine());
    cateto1= Math.Sqrt(Math.Pow (cateto2, 2) + Math.Pow (hipotenusa, 2));
    
    Console.WriteLine("hipotenusa: {0:F2}" , cateto1);
    
  }
}