using System;

class Program
{
    public static void Main(string[] args)
    {

        double x1, y1, x2, y2, distancia;

        Console.WriteLine("Digite o primeiro valor ");
        x1 = double.Parse(Console.ReadLine());
        Console.WriteLine("Digite o segundo valor");
        y1 = double.Parse(Console.ReadLine());
        Console.WriteLine("Digite o terceiro valor");
        x2 = double.Parse(Console.ReadLine());
        Console.WriteLine("Digite o quarto valor");
        y2 = double.Parse(Console.ReadLine());

        distancia = Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));

        Console.WriteLine("A distancia de um ponto a outro é:" + distancia);
    }
}