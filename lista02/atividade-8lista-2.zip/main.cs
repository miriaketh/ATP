using System;

class Program {
  public static void Main (string[] args) {
    double salario = 0;

    Console.WriteLine ("Digite o salário do funcionário:");
    salario = double.Parse(Console.ReadLine());

    Console.WriteLine("Escolha uma opção:");
    Console.WriteLine("Aumento de 8% no salário");
    Console.WriteLine("Aumento de 11% no salário");
    Console.WriteLine("Aumento fixo no salário");

    char opcao = char.Parse(Console.ReadLine().ToUpper());

    double novoSalario = 0;
    switch (opcao) {
    case 'A':
      novoSalario = salario * 1.08;
      break;

    case 'B':
      novoSalario = salario * 1.11;
      break;

    case 'C':
      if (salario <= 1000){
        novoSalario = salario + 350;
      }
      else {
        novoSalario = salario + 200;
      }
      break;
    default: Console.WriteLine("Erro");
      break;  
    }  
    Console.WriteLine("Novo salário: R$" + novoSalario);
  }
}