using System;

class Program {
  public static void Main (string[] args) {
    int numero1, numero2;
    Console.WriteLine ("Digite um número inteiro:");
    numero1 = Convert.ToInt32(Console.ReadLine());

    Console.WriteLine("Digite o segundo número inteiro:");
    numero2 = Convert.ToInt32(Console.ReadLine());

    int resultado = numero1 + numero2;
    
    if (resultado >= 10)
    {
      resultado += 5;
    }
    else
    {
      resultado += 7;
    }
    Console.WriteLine("O resultado é: " + resultado);
  }
}