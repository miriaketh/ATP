using System;

class Program {
  public static void Main (string[] args) {
    
    Console.WriteLine ("Digite o primeiro número:");
    double numero1 = Convert.ToDouble(Console.ReadLine());

    Console.WriteLine ("Digite o segundo número:");
    double numero2 = Convert.ToDouble(Console.ReadLine());

    double maiorNumero = Math.Max(numero1, numero2);
    Console.WriteLine("o maior número é: " + maiorNumero);
  }
}