using System;

class Program {
  public static void Main (string[] args) {

    Console.WriteLine ("Digite a velocidade permitida:");
    double velocidadePermitida = double.Parse(Console.ReadLine());

    Console.WriteLine ("Digite a velocidade do motorista:");
    double velocidadeMotorista = double.Parse(Console.ReadLine());

    if (velocidadeMotorista <= velocidadePermitida) {
      Console.WriteLine("Motorista respeitou a lei");
    }
    
    else if (velocidadeMotorista > velocidadePermitida && velocidadeMotorista <= velocidadePermitida + 10) {
      Console.WriteLine("Motorista recebeu uma multa de R$50,00");
    }
    
    else if (velocidadeMotorista > velocidadePermitida + 10 && velocidadeMotorista <= velocidadePermitida + 30) {
      Console.WriteLine("Motorista recebeu uma multa de R$100,00");
    }

    else {
      Console.WriteLine("Motorista recebeu uma multa de R$200,00");
    }
  }
}