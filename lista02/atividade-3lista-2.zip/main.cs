using System;

class Program {
  public static void Main (string[] args) {
    Console.WriteLine ("Escreva uma equação do primeiro grau formato: ax + b = 0");

    Console.WriteLine("Escreva o valor de a:");
    double a = double.Parse(Console.ReadLine());

    Console.WriteLine("Escreva o valor de b:");
    double b = double.Parse(Console.ReadLine());

    double raiz = -b / a;
    Console.WriteLine("A raiz da equação é: " + raiz);
  }
}