using System;

class Program {
  public static void Main (string[] args) {
    Console.WriteLine ("Digite seu ano de nascimento:");
    int anoNascimento = int.Parse(Console.ReadLine());
    int anoAtual = DateTime.Now.Year;
    Console.WriteLine("Já fez aniversário esse ano? (s/n");
    string respostaAniversario = Console.ReadLine().ToUpper();
    int idade; 
    if (respostaAniversario == "S")
    {
      idade = anoAtual - anoNascimento;
    }
    else {
      idade = anoAtual - anoNascimento - 1;
    }
    Console.WriteLine($"Você tem {idade} anos");
   if (idade >= 18)
    {
      Console.WriteLine("Você já pode tirar a carteira de motorista");
      
    }
    else 
    {
      Console.WriteLine("Você ainda não pode tirar a carteira de motorista");
    }
  }
  
}