using System;

class Program {
  public static void Main (string[] args) {
    double apartamento = 75;
    double promocao = 0.75;
     
    Console.WriteLine ("Insira a diária");
    double diaria = double.Parse(Console.ReadLine());

    double diariaPromocao = diaria * promocao;
    double valorArrecadado80 = (apartamento * 0.8 * diariaPromocao);
    double valorArrecadado50 = (apartamento / 2) * diaria;
    double diferenca = valorArrecadado80 - valorArrecadado50;

    Console.WriteLine("Diária promocional = " + diariaPromocao);
    Console.WriteLine("Valor arrecadado com 80% de ocupação = " + valorArrecadado80);
    Console.WriteLine("Valor arrecadado com 50% de ocupação = " + valorArrecadado50);
    Console.WriteLine("Diferença entre os valores = " + diferenca);
    
  }
}