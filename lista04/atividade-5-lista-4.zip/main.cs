using System;

class Program {
  public static void Main (string[] args) {

    //declarar uma variavel para receber o resultado da funcao

    int result;

    //pedir dois numeros e os transferir para a funcao

    Console.WriteLine ("Digite dois numeros inteiros diferentes de 0");
    int n1 = int.Parse(Console.ReadLine());
    int n2 = int.Parse(Console.ReadLine());
    result = MDC(n1,n2);

    Console.WriteLine("O MDC é {0}", result);
  }

  static int MDC(int a, int b){

    //declarar variavel i fora da repeticao

    int i;

    //garantir que a seja menor que b para fazermos a verificacao

    if (a>b){
      int aux = a;
      a = b;
      b = aux;
    }

    //a sendo menor q b, vamos fazendo as divisoes para saber o mdc

    for (i = a; i>=1 && (i%a==0 && i%b==0); i--);
    return i;
  }
}