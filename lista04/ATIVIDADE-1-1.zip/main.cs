using System;

class Program {
  public static void Main (string[] args) {

    //inicio do codigo recebendo nosso parametro para o for, esse parametro sera a quantidade de alunos a ter as notas dentro da media

    Console.WriteLine ("Quantos alunos terão a nota calculada? ");
    int nA = int.Parse(Console.ReadLine());

    // defini um if > 0 para caso nao receba alunos o programa encerre, mas do contrario ele ira continuar como parametro para o for, onde chamamos nosso processo

    if (nA > 0) {
      for(int i = 1; i <= nA; i++){
        media(i);
      }
    }
  }


static void media(int aluno){

// defini um variavel med para ser definida como media do aluno

  double med = 0;

  //receber e armazenar as notas do aluno em x y z

  Console.WriteLine("Escreva as notas do aluno" + aluno);
  double x = double.Parse(Console.ReadLine());
  double y = double.Parse(Console.ReadLine());
  double z = double.Parse(Console.ReadLine());

  //Fazer uma multipla escolha para cada situação em seguida armazenalas em uma sequencia de if e else.

  Console.WriteLine("Escolha uma opção: "); 
  Console.WriteLine("A - Média Aritmética");
  Console.WriteLine("P - Média Ponderada");	

  char resp = char.Parse(Console.ReadLine());

  if (resp == 'A') {
  med = (x + y + z)/3;
  }

  else if (resp == 'P'){
  med = (x*5 + y*3 + z*2)/10;
  }

  //como capricho caso a pessoa n escolha A ou P o programa informa uma opcao invalida

    else {
    Console.WriteLine("Opção inválida");
    }

//imprimir a media do aluno

    Console.WriteLine("A média do aluno é: " + med);
  }
}
