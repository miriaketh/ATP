using System;

class Program {
  public static void Main (string[] args) {

    //declaracao de variaveis, evitar problemas la na frente

    char resposta;
    double media = 0;

    //comecando a repeticao, escolhi o do while pq na atividade pediu n alunos, ent a pessoa vai conferindo quantos quiser.

  do{  Console.WriteLine ("Conferir a media do aluno (s para conferir / qualquer outro para sair)"); 
    resposta = char.Parse(Console.ReadLine());

    //basico if else pro programa saber se tem que continuar ou n, e nos chamamos o procedimento e damos a media pra ele.

    if (resposta == 's'){
      Console.WriteLine("Digite a media do aluno: ");
      media = double.Parse(Console.ReadLine());
      conceito(media);
    }
    }while(resposta == 's');
    Console.WriteLine("Programa encerrou");
  }


  static void conceito(double media){

    // so uma sequencia grande de if e else para saber o conceito do rapaz.

    if(media <= 39){
      Console.WriteLine("F");
    }
    else if (media > 39 && media <= 59){
      Console.WriteLine("E");
    }
    else if (media > 59 && media <= 69){
      Console.WriteLine("D");
    }
    else if (media > 69 && media <= 79){
      Console.WriteLine("C");
    }
    else if (media > 79 && media <= 89){
      Console.WriteLine("B");
    }
    else {
      Console.WriteLine("A");
    }

  }
}