using System;

class Program {
  public static void Main (string[] args) {

    //declarar as variaveis para n ter dor de cabeca dps

    int x;
    int y;
    int z;

    //pegar nosso delimitador para o for

    Console.WriteLine ("Digite quantos triangulos pretende verificar: ");
    int n = int.Parse(Console.ReadLine());

    //dentro do for nos vamos pegando os lados do triangulo para ter varios triangulos, esses valores sao transferidos para nosso processo chamado verificador

    for (int i = 0; i <= n; i++){
      Console.WriteLine("Digite os lados do triangulo");
      x = int.Parse(Console.ReadLine());
      y = int.Parse(Console.ReadLine());
      z = int.Parse(Console.ReadLine());
      verificador(x, y, z);

    }
  }

  static void verificador(int x, int y, int z){

    //sequencia de if e else para poder saber se e um triangulo e qual triangulo que e

    if (x < (y + z) && y < (x + z) &&  z < (y + x)){
      Console.WriteLine("É um triangulo");
      if (x == y && y == z){
        Console.WriteLine("Equilatero");
      }
      else if (x == y || y == z || x == z){
        Console.WriteLine("Isosceles");
      }
      else{
        Console.WriteLine("Escaleno");
      }
    } else {
    Console.WriteLine("Não é um triangulo");}
  }
}