using System;

class Program {
  public static void Main (string[] args) {

    //declarando variavel para receber funcao

    string info;

    //recebendo idade

    Console.WriteLine ("Insira a idade do nadador: ");
    int idade = int.Parse(Console.ReadLine());

    //transferindo idade para funcao

    info = categoria(idade);

    Console.WriteLine("A categoria do nadador é: " + info);
  }

  static string categoria(int idade){

    //declarando variavel para receber categoria

    string categoria;

    //if e else if para indicar categoria

    if (idade >= 5){
      categoria = "F";
    }
    else if(idade >=8){
      categoria = "E";
    }
    else if(idade >=11){
      categoria = "D";
    }
    else if(idade >=14){
      categoria = "C";
    }
    else if(idade >=16){
      categoria = "B";
    }
    else {
      categoria = "A";
    }
    return categoria;
  }
}