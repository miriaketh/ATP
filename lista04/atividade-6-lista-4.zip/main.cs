using System;

class Program {
  public static void Main (string[] args) {

    //declarando variaveis para n esquecer dps

    char resposta;
    int n;
    bool resultado;

    //comecando a estrutura de repeticao, como nao sabemos quantas vezes vai repetir criamos uma maneira de encerrar o programa, nesse caso enquanto a resp for s o programa vai continuar rodando

    do {
      Console.WriteLine("Verificar se o numero e positivo ou negativo? (s/qualquer tecla para sair)");
      resposta = char.Parse(Console.ReadLine());

      if (resposta=='s')
      {

        //pedindo numero para verificar se e positivo ou negativo

      Console.WriteLine("Digite um numero inteiro: ");
      n = int.Parse(Console.ReadLine());

        //puxando a resposta da nossa funcao e fazendo um if else pra imprimir positivo ou negaitvo

      resultado = verificador(n);

      if (resultado == true)
        {
        Console.WriteLine("Positivo");
      } 

        else {Console.WriteLine("Negativo");}  
      }
    }while(resposta=='s');
  }

  static bool verificador(int n){

    //criando positivo para true e negativo para false

    bool positivo = true;
    bool negativo = false;

    //o simples, maior q zero true se nao false

    if (n >0){
      return positivo;
    }
    return negativo;
  }
}